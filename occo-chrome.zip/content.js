(() => {
  const DEFAULTS = {
    enabled: true,
    playbackRate: 3,
    muted: false,
    autoNextLesson: true,
    fallbackWaitSeconds: 20,
    extraWaitSeconds: 1,
    lastStatus: "暂无状态",
    lastStatusAt: ""
  };

  let settings = { ...DEFAULTS };
  let observerTimer = null;
  let fallbackTimer = null;
  let countdownDoneTimer = null;
  let lastNonVideoKey = "";

  const log = (msg) => console.log(`[倒计时安全版课程助手] ${msg}`);

  function saveStatus(text) {
    chrome.storage.sync.set({
      lastStatus: text,
      lastStatusAt: new Date().toLocaleString()
    });
  }

  function loadSettings() {
    chrome.storage.sync.get(DEFAULTS, (result) => {
      settings = { ...DEFAULTS, ...result };
      scheduleWork();
    });
  }

  function isElementVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity) !== 0 &&
      rect.width > 20 &&
      rect.height > 20;
  }

  function getBestVideo() {
    const videos = Array.from(document.querySelectorAll("video"));
    const visibleVideos = videos.filter(isElementVisible);
    const usableVideos = visibleVideos.filter(v => !Number.isNaN(v.duration) && v.duration > 0);
    return usableVideos[0] || visibleVideos[0] || null;
  }

  function findByTextOrClass(patterns) {
    const els = Array.from(document.querySelectorAll("button, a, div, span, i, li"));
    return els.find(el => {
      if (!isElementVisible(el)) return false;
      const text = (el.innerText || el.textContent || "").trim();
      const cls = el.className ? String(el.className) : "";
      const title = el.getAttribute("title") || "";
      const aria = el.getAttribute("aria-label") || "";
      const all = `${text} ${cls} ${title} ${aria}`.toLowerCase();
      return patterns.some(p => all.includes(p.toLowerCase()));
    }) || null;
  }

  function clearNonVideoTimers() {
    if (fallbackTimer) clearTimeout(fallbackTimer);
    if (countdownDoneTimer) clearTimeout(countdownDoneTimer);
    fallbackTimer = null;
    countdownDoneTimer = null;
  }

  async function handleVideo(video) {
    if (!settings.enabled || !video) return;

    clearNonVideoTimers();
    lastNonVideoKey = "";

    video.muted = Boolean(settings.muted);
    video.playbackRate = Number(settings.playbackRate) || 1;

    if (!video.dataset.safeCountdownHelperBound) {
      video.dataset.safeCountdownHelperBound = "1";

      video.addEventListener("ended", () => {
        saveStatus("视频已结束，准备尝试进入下一节");
        setTimeout(tryNextLesson, 1500);
      });

      video.addEventListener("pause", () => {
        if (!settings.enabled || video.ended) return;
        setTimeout(() => {
          if (settings.enabled && video.paused && !video.ended) {
            video.play().catch(() => {});
          }
        }, 3000);
      });
    }

    try {
      await video.play();
      saveStatus("识别为视频，已尝试正常播放");
    } catch (err) {
      saveStatus("识别为视频，但浏览器阻止自动播放；请手动点一次播放");
      log(`video play blocked: ${err && err.message ? err.message : err}`);
    }
  }

  function tryNextLesson() {
    if (!settings.enabled || !settings.autoNextLesson) return;

    const next = findByTextOrClass([
      "下一节", "下一课", "下一章", "下一个", "next", "right"
    ]);

    if (next) {
      next.click();
      saveStatus("已尝试点击下一节");
      setTimeout(() => {
        lastNonVideoKey = "";
        scheduleWork();
      }, 2000);
    } else {
      saveStatus("没有找到下一节按钮");
    }
  }

  function getCountdownInfo() {
    const els = Array.from(document.querySelectorAll("div, span, p, strong"));
    for (const el of els) {
      if (!isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || "").trim();
      if (!text) continue;

      // 示例：完成倒计时：10s / 完成倒计时: 10秒
      const match = text.match(/完成倒计时\s*[：:]\s*(\d+)\s*(s|秒)?/i);
      if (match) {
        return {
          seconds: Number(match[1]),
          text
        };
      }
    }
    return null;
  }

  function getPageKey() {
    const active = findByTextOrClass(["active", "current", "选中"]);
    const title = active ? (active.innerText || active.textContent || "").trim() : "";
    return `${location.href}::${title}`.slice(0, 300);
  }

  function handleNonVideo() {
    if (!settings.enabled || !settings.autoNextLesson) return;

    const key = getPageKey();

    // 新课件才重置计时器；同一课件只观察倒计时变化。
    if (key !== lastNonVideoKey) {
      clearNonVideoTimers();
      lastNonVideoKey = key;

      const fallback = Math.max(1, Number(settings.fallbackWaitSeconds) || 20);
      fallbackTimer = setTimeout(() => {
        if (getBestVideo()) {
          saveStatus("检测到视频已加载，取消非视频兜底跳转");
          scheduleWork();
          return;
        }

        const info = getCountdownInfo();
        if (info && info.seconds > 1) {
          saveStatus(`检测到完成倒计时：${info.seconds}s，继续等待`);
          scheduleWork();
          return;
        }

        saveStatus("未检测到倒计时或倒计时已到 1s/结束，准备进入下一节");
        tryNextLesson();
      }, fallback * 1000);
    }

    const info = getCountdownInfo();

    if (info) {
      if (info.seconds > 1) {
        saveStatus(`识别为非视频课件，等待平台倒计时：${info.seconds}s`);
        return;
      }

      if (!countdownDoneTimer) {
        const extra = Math.max(0, Number(settings.extraWaitSeconds) || 0);
        saveStatus(`平台倒计时已到 1s 或结束，${extra}s 后进入下一节`);
        countdownDoneTimer = setTimeout(() => {
          countdownDoneTimer = null;
          if (!getBestVideo()) tryNextLesson();
        }, extra * 1000);
      }
      return;
    }

    const fallback = Math.max(1, Number(settings.fallbackWaitSeconds) || 20);
    saveStatus(`识别为非视频课件，未找到平台倒计时；${fallback}s 后兜底进入下一节`);
  }

  function scheduleWork() {
    if (!settings.enabled) {
      saveStatus("已关闭");
      clearNonVideoTimers();
      return;
    }

    const video = getBestVideo();
    if (video) {
      handleVideo(video);
    } else {
      handleNonVideo();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const key of Object.keys(changes)) {
      settings[key] = changes[key].newValue;
    }
    clearNonVideoTimers();
    lastNonVideoKey = "";
    scheduleWork();
  });

  const observer = new MutationObserver(() => {
    clearTimeout(observerTimer);
    observerTimer = setTimeout(scheduleWork, 600);
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    characterData: true
  });

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) scheduleWork();
  });

  loadSettings();

  // 安全说明：
  // 不修改平台倒计时，只读取页面上的“完成倒计时：Xs”文本。
  // 不 hook XMLHttpRequest/fetch；不调用学习进度接口；不读取 document.cookie。
})();



/* === 倒计时读取显示补丁：只读取页面文字，不修改平台倒计时 === */
(function countdownReaderPatch(){
  if (window.__countdownReaderPatchInstalled) return;
  window.__countdownReaderPatchInstalled = true;

  function visible(el){
    if (!el) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== "none" && s.visibility !== "hidden" && r.width > 0 && r.height > 0;
  }

  function readCountdownText(){
    const nodes = Array.from(document.querySelectorAll("div,span,p,strong,b"));
    for (const el of nodes) {
      if (!visible(el)) continue;
      const text = (el.innerText || el.textContent || "").trim();
      if (!text) continue;
      const m = text.match(/完成倒计时\s*[：:]\s*(\d+)\s*(s|秒)?/i);
      if (m) return { seconds: Number(m[1]), text };
    }
    return null;
  }

  function ensurePanel(){
    let panel = document.getElementById("__safe_countdown_panel");
    if (panel) return panel;
    panel = document.createElement("div");
    panel.id = "__safe_countdown_panel"; panel.style.display='none';
    panel.style.cssText = [
      "position:fixed",
      "right:16px",
      "bottom:16px",
      "z-index:2147483647",
      "background:rgba(0,0,0,.72)",
      "color:#fff",
      "padding:8px 10px",
      "border-radius:8px",
      "font-size:13px",
      "line-height:1.4",
      "font-family:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      "box-shadow:0 2px 10px rgba(0,0,0,.18)"
    ].join(";");
    panel.textContent = "";
    document.documentElement.appendChild(panel);
    return panel;
  }

  function tick(){
    const info = readCountdownText();
    const panel = ensurePanel();

    if (info) {
      panel.textContent = "";
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
        chrome.storage.sync.set({
          pageCountdownSeconds: info.seconds,
          pageCountdownText: info.text,
          pageCountdownAt: new Date().toLocaleString()
        });
      }
    } else {
      panel.textContent = "";
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
        chrome.storage.sync.set({
          pageCountdownSeconds: null,
          pageCountdownText: "未检测到",
          pageCountdownAt: new Date().toLocaleString()
        });
      }
    }
  }

  setInterval(tick, 1000);
  tick();
})();




/* === 修复补丁 v2：识别“非视频完成倒计时”，1s 卡住也跳转；增强下一节点击 === */
(function countdownNextFixV2(){
  if (window.__countdownNextFixV2Installed) return;
  window.__countdownNextFixV2Installed = true;

  let jumped = false;
  let lastUrl = location.href;

  function visible(el){
    if (!el) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== "none" && s.visibility !== "hidden" && r.width > 0 && r.height > 0;
  }

  function textOf(el){
    return (el && (el.innerText || el.textContent) || "").trim();
  }

  function readCountdown(){
    const nodes = Array.from(document.querySelectorAll("div,span,p,strong,b"));
    for (const el of nodes) {
      if (!visible(el)) continue;
      const text = textOf(el);
      if (!text) continue;

      // 兼容：
      // 完成倒计时：10s
      // 非视频完成倒计时：1s
      // 非视频完成倒计时: 1s
      const m = text.match(/(?:非视频)?完成倒计时\s*[：:]\s*(\d+)\s*(s|秒)?/i);
      if (m) return { seconds: Number(m[1]), text };
    }
    return null;
  }

  function save(sec, raw){
    try {
      chrome.storage.sync.set({
        pageCountdownSeconds: sec,
        pageCountdownText: raw || (sec == null ? "未检测到" : String(sec)),
        pageCountdownAt: new Date().toLocaleString(),
        lastStatus: sec == null ? "未检测到页面倒计时" : ("检测到页面倒计时：" + sec + "s"),
        lastStatusAt: new Date().toLocaleString()
      });
    } catch(e) {}
  }

  function getClickable(el){
    while (el && el !== document.body) {
      const tag = (el.tagName || "").toLowerCase();
      const role = el.getAttribute && el.getAttribute("role");
      if (tag === "button" || tag === "a" || role === "button" || el.onclick) return el;
      el = el.parentElement;
    }
    return null;
  }

  function clickHuman(el){
    if (!el) return false;
    const target = getClickable(el) || el;
    try { target.scrollIntoView({block:"center", inline:"center"}); } catch(e) {}
    try {
      ["pointerdown","mousedown","mouseup","click"].forEach(type => {
        target.dispatchEvent(new MouseEvent(type, {bubbles:true, cancelable:true, view:window}));
      });
      return true;
    } catch(e) {
      try { target.click(); return true; } catch(_) {}
    }
    return false;
  }

  function findNextByText(){
    const patterns = ["下一节", "下一课", "下一个", "下一章", "next"];
    const els = Array.from(document.querySelectorAll("button,a,li,div,span"));
    return els.find(el => {
      if (!visible(el)) return false;
      const t = textOf(el).toLowerCase();
      const cls = String(el.className || "").toLowerCase();
      const title = (el.getAttribute("title") || "").toLowerCase();
      const all = t + " " + cls + " " + title;
      return patterns.some(p => all.includes(p.toLowerCase()));
    }) || null;
  }

  function findNextLessonByActiveNode(){
    // 课程目录常见结构：当前激活项的下一个兄弟节点/下一个同级课件
    const active = document.querySelector(
      ".third-level-box.active, .active.third-level-box, .active[class*='level'], .active[class*='lesson'], li.active, .current"
    );
    if (!active) return null;

    let n = active.nextElementSibling;
    while (n) {
      if (visible(n) && textOf(n)) return n;
      n = n.nextElementSibling;
    }

    // 如果当前项在父级内部，尝试找父级后面的可见节点
    const parent = active.parentElement;
    if (parent) {
      n = parent.nextElementSibling;
      while (n) {
        if (visible(n) && textOf(n)) return n;
        n = n.nextElementSibling;
      }
    }

    return null;
  }

  function goNext(){
    const byText = findNextByText();
    if (byText && clickHuman(byText)) return true;

    const byActive = findNextLessonByActiveNode();
    if (byActive && clickHuman(byActive)) return true;

    // 已移除键盘右方向键兜底，避免测验/讨论页误跳外链
    return false;
  }

  function tick(){
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      jumped = false;
    }

    const info = readCountdown();
    if (!info) {
      save(null, "未检测到");
      return;
    }

    save(info.seconds, info.text);

    // 这个平台会卡在 1s，所以 <=1 当作可以进入下一节
    if (info.seconds <= 1 && !jumped) {
      jumped = true;
      try {
        chrome.storage.sync.set({
          lastStatus: "倒计时已到 1s，正在尝试进入下一节",
          lastStatusAt: new Date().toLocaleString()
        });
      } catch(e) {}

      setTimeout(() => {
        const ok = goNext();
        try {
          chrome.storage.sync.set({
            lastStatus: ok ? "已触发下一节" : "未找到下一节按钮，请手动点一次下一节",
            lastStatusAt: new Date().toLocaleString()
          });
        } catch(e) {}
        setTimeout(() => { jumped = false; }, 5000);
      }, 800);
    }
  }

  setInterval(tick, 1000);
  tick();
})();




/* === 防误跳补丁 v3：测验/讨论/外链页面不自动下一节，避免打开 cq.smartedu.cn 循环 === */
(function safeUnknownPageGuardV3(){
  if (window.__safeUnknownPageGuardV3Installed) return;
  window.__safeUnknownPageGuardV3Installed = true;

  const BLOCK_WORDS = [
    "测验", "测试", "考试", "作业", "讨论", "论坛", "问卷", "投票", "答题",
    "quiz", "exam", "test", "homework", "discussion"
  ];

  function visible(el){
    if (!el) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== "none" && s.visibility !== "hidden" && r.width > 0 && r.height > 0;
  }

  function pageText(){
    return (document.body && (document.body.innerText || document.body.textContent) || "").slice(0, 3000);
  }

  function isBlockedType(){
    const text = pageText().toLowerCase();
    return BLOCK_WORDS.some(w => text.includes(w.toLowerCase()));
  }

  function hasVideo(){
    return Array.from(document.querySelectorAll("video")).some(v => {
      const r = v.getBoundingClientRect();
      return r.width > 20 && r.height > 20;
    });
  }

  function hasCountdown(){
    return /(?:非视频)?完成倒计时\s*[：:]\s*\d+\s*(?:s|秒)?/i.test(pageText());
  }

  function isSafeAutoNextContext(){
    // 只允许两种情况自动下一节：
    // 1. 视频页面
    // 2. 明确有“完成倒计时”的非视频文档/PPT页面
    // 测验/讨论/作业等一律不自动跳，避免误点外链。
    if (isBlockedType()) return false;
    return hasVideo() || hasCountdown();
  }

  function setStatus(text){
    try {
      chrome.storage.sync.set({
        lastStatus: text,
        lastStatusAt: new Date().toLocaleString()
      });
    } catch(e) {}
  }

  // 捕获明显外链误点：插件自动触发时，拦截 cq.smartedu.cn 新页面。
  document.addEventListener("click", function(e){
    const a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
    if (!a) return;
    const href = a.href || "";
    if (href.includes("cq.smartedu.cn") && !isSafeAutoNextContext()) {
      e.preventDefault();
      e.stopPropagation();
      setStatus("检测到测验/讨论/未知非视频页面，已阻止自动打开外链");
    }
  }, true);

  // 覆盖/限制旧版补丁的下一节行为：未知页面不允许执行。
  const oldClick = HTMLElement.prototype.click;
  HTMLElement.prototype.click = function(){
    const txt = (this.innerText || this.textContent || this.getAttribute("title") || "").trim();
    const href = this.href || this.getAttribute && this.getAttribute("href") || "";
    const looksNext = /下一节|下一课|下一章|下一个|next/i.test(txt + " " + this.className);
    const looksExternal = String(href).includes("cq.smartedu.cn");

    if ((looksNext || looksExternal) && !isSafeAutoNextContext()) {
      setStatus("当前像是测验/讨论/未知页面，已暂停自动下一节");
      return;
    }
    return oldClick.apply(this, arguments);
  };

  setInterval(() => {
    if (!hasVideo() && !hasCountdown() && isBlockedType()) {
      setStatus("识别为测验/讨论/作业类页面，已暂停自动下一节");
    } else if (!hasVideo() && !hasCountdown()) {
      setStatus("未知非视频页面，未检测到完成倒计时，已暂停自动下一节");
    }
  }, 2000);
})();




/* === 倒计时读取修复 v4：只读平台页面倒计时，排除插件自己的状态框 === */
(function realPlatformCountdownFixV4(){
  if (window.__realPlatformCountdownFixV4Installed) return;
  window.__realPlatformCountdownFixV4Installed = true;

  let lastRealSeconds = null;
  let lastRealText = "";
  let jumping = false;

  function visible(el){
    if (!el) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== "none" && s.visibility !== "hidden" && r.width > 0 && r.height > 0;
  }

  function inPluginUI(el){
    if (!el) return false;
    return Boolean(
      el.closest("#__safe_countdown_panel") ||
      el.closest("[id*='safe_countdown']") ||
      el.closest("[id*='countdown_panel']") ||
      el.closest("[class*='popup']") ||
      el.closest("[class*='card']")
    );
  }

  function textOf(el){
    return (el && (el.innerText || el.textContent) || "").trim();
  }

  function readRealCountdown(){
    const nodes = Array.from(document.querySelectorAll("div,span,p,strong,b"));
    let best = null;

    for (const el of nodes) {
      if (!visible(el) || inPluginUI(el)) continue;

      const text = textOf(el);
      if (!text) continue;

      // 只读平台原文：完成倒计时：8s
      // 明确排除插件自己写的：非视频完成倒计时：9s
      if (/非视频完成倒计时/i.test(text)) continue;

      const m = text.match(/(^|[\s　])完成倒计时\s*[：:]\s*(\d+)\s*(s|秒)?($|[\s　])/i) ||
                text.match(/完成倒计时\s*[：:]\s*(\d+)\s*(s|秒)?/i);

      if (!m) continue;

      const sec = Number(m[2] || m[1]);
      if (Number.isFinite(sec)) {
        const rect = el.getBoundingClientRect();
        best = { seconds: sec, text, top: rect.top, right: rect.right };
        break;
      }
    }

    return best;
  }

  function saveStatus(sec, raw){
    try {
      chrome.storage.sync.set({
        pageCountdownSeconds: sec,
        pageCountdownText: raw || (sec == null ? "未检测到" : String(sec)),
        pageCountdownAt: new Date().toLocaleString(),
        lastStatus: sec == null ? "未检测到平台倒计时" : ("识别到平台倒计时：" + sec + "s"),
        lastStatusAt: new Date().toLocaleString()
      });
    } catch(e) {}
  }

  function getClickable(el){
    while (el && el !== document.body) {
      const tag = (el.tagName || "").toLowerCase();
      const role = el.getAttribute && el.getAttribute("role");
      if (tag === "button" || tag === "a" || role === "button" || el.onclick) return el;
      el = el.parentElement;
    }
    return null;
  }

  function clickHuman(el){
    if (!el) return false;
    const target = getClickable(el) || el;
    try { target.scrollIntoView({block:"center", inline:"center"}); } catch(e) {}
    try {
      ["pointerdown","mousedown","mouseup","click"].forEach(type => {
        target.dispatchEvent(new MouseEvent(type, {bubbles:true, cancelable:true, view:window}));
      });
      return true;
    } catch(e) {
      try { target.click(); return true; } catch(_) {}
    }
    return false;
  }

  function findNext(){
    const patterns = ["下一节", "下一课", "下一章", "下一个", "next"];
    const els = Array.from(document.querySelectorAll("button,a,li,div,span"));
    return els.find(el => {
      if (!visible(el) || inPluginUI(el)) return false;
      const t = textOf(el).toLowerCase();
      const cls = String(el.className || "").toLowerCase();
      const title = (el.getAttribute("title") || "").toLowerCase();
      const all = t + " " + cls + " " + title;
      return patterns.some(p => all.includes(p.toLowerCase()));
    }) || null;
  }

  function findNextByCourseList(){
    const active = document.querySelector(
      ".third-level-box.active, .active.third-level-box, .active[class*='level'], .active[class*='lesson'], li.active, .current"
    );
    if (!active || inPluginUI(active)) return null;

    let n = active.nextElementSibling;
    while (n) {
      if (visible(n) && !inPluginUI(n) && textOf(n)) return n;
      n = n.nextElementSibling;
    }
    return null;
  }

  function goNext(){
    return clickHuman(findNext()) || clickHuman(findNextByCourseList());
  }

  function tick(){
    const info = readRealCountdown();

    if (info) {
      lastRealSeconds = info.seconds;
      lastRealText = info.text;
      saveStatus(info.seconds, info.text);
    } else {
      // 不再读取插件自己的“非视频完成倒计时”，避免显示错乱
      saveStatus(null, "未检测到");
      return;
    }

    // 平台可能停在 1s，所以 1s 当作结束
    if (lastRealSeconds <= 1 && !jumping) {
      jumping = true;
      try {
        chrome.storage.sync.set({
          lastStatus: "平台倒计时已到 1s，准备进入下一节",
          lastStatusAt: new Date().toLocaleString()
        });
      } catch(e) {}

      setTimeout(() => {
        const ok = goNext();
        try {
          chrome.storage.sync.set({
            lastStatus: ok ? "已点击下一节" : "未找到下一节按钮，请手动点一次",
            lastStatusAt: new Date().toLocaleString()
          });
        } catch(e) {}
        setTimeout(() => { jumping = false; }, 6000);
      }, 1000);
    }
  }

  setInterval(tick, 500);
  tick();
})();




/* === 倒计时读取修复 v5：从真实页面文本节点读取“完成倒计时：16s”，不读取插件弹窗 === */
(function realPlatformCountdownFixV5(){
  if (window.__realPlatformCountdownFixV5Installed) return;
  window.__realPlatformCountdownFixV5Installed = true;

  let jumping = false;
  let lastJumpAt = 0;

  function inPluginUI(node){
    const el = node && (node.nodeType === 1 ? node : node.parentElement);
    if (!el || !el.closest) return false;
    return Boolean(
      el.closest("#__safe_countdown_panel") ||
      el.closest("[id*='safe_countdown']") ||
      el.closest("[id*='countdown_panel']") ||
      el.closest("[id='pageCountdownBox']") ||
      el.closest("[class*='status']") ||
      el.closest("[class*='note']")
    );
  }

  function isVisibleElement(el){
    if (!el) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== "none" && s.visibility !== "hidden" && r.width > 0 && r.height > 0;
  }

  function parseCountdown(text){
    if (!text) return null;
    // 兼容：完成倒计时：16s / 完成倒计时:16秒 / 文本中夹杂空格换行
    const m = String(text).replace(/\s+/g, " ").match(/完成倒计时\s*[：:]\s*(\d+)\s*(?:s|秒)?/i);
    if (!m) return null;
    return Number(m[1]);
  }

  function readFromTextNodes(){
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (inPluginUI(node)) continue;
      const text = node.nodeValue || "";
      const sec = parseCountdown(text);
      if (sec !== null && Number.isFinite(sec)) {
        const parent = node.parentElement;
        if (!parent || isVisibleElement(parent)) {
          return { seconds: sec, text: text.trim() };
        }
      }
    }
    return null;
  }

  function readFromElements(){
    const els = Array.from(document.querySelectorAll("div,span,p,strong,b,font,label"));
    for (const el of els) {
      if (inPluginUI(el) || !isVisibleElement(el)) continue;
      const own = Array.from(el.childNodes)
        .filter(n => n.nodeType === Node.TEXT_NODE)
        .map(n => n.nodeValue)
        .join(" ");
      const text = own || el.textContent || "";
      const sec = parseCountdown(text);
      if (sec !== null && Number.isFinite(sec)) {
        return { seconds: sec, text: text.trim() };
      }
    }
    return null;
  }

  function readCountdown(){
    return readFromTextNodes() || readFromElements();
  }

  function setStorage(sec, raw, status){
    try {
      chrome.storage.sync.set({
        pageCountdownSeconds: sec,
        pageCountdownText: raw || (sec == null ? "未检测到" : ("完成倒计时：" + sec + "s")),
        pageCountdownAt: new Date().toLocaleString(),
        lastStatus: status || (sec == null ? "未检测到平台倒计时" : ("识别到平台倒计时：" + sec + "s")),
        lastStatusAt: new Date().toLocaleString()
      });
    } catch(e) {}
  }

  function visible(el){
    return el && isVisibleElement(el) && !inPluginUI(el);
  }

  function textOf(el){
    return (el && (el.innerText || el.textContent) || "").trim();
  }

  function getClickable(el){
    while (el && el !== document.body) {
      const tag = (el.tagName || "").toLowerCase();
      const role = el.getAttribute && el.getAttribute("role");
      if (tag === "button" || tag === "a" || role === "button" || el.onclick) return el;
      el = el.parentElement;
    }
    return null;
  }

  function clickHuman(el){
    if (!el) return false;
    const target = getClickable(el) || el;
    try { target.scrollIntoView({block:"center", inline:"center"}); } catch(e) {}
    try {
      ["pointerdown","mousedown","mouseup","click"].forEach(type => {
        target.dispatchEvent(new MouseEvent(type, {bubbles:true, cancelable:true, view:window}));
      });
      return true;
    } catch(e) {
      try { target.click(); return true; } catch(_) {}
    }
    return false;
  }

  function findNext(){
    const patterns = ["下一节", "下一课", "下一章", "下一个", "next"];
    const els = Array.from(document.querySelectorAll("button,a,li,div,span"));
    return els.find(el => {
      if (!visible(el)) return false;
      const all = (textOf(el) + " " + String(el.className || "") + " " + (el.getAttribute("title") || "")).toLowerCase();
      return patterns.some(p => all.includes(p.toLowerCase()));
    }) || null;
  }

  function findNextByCourseList(){
    const active = document.querySelector(
      ".third-level-box.active, .active.third-level-box, .active[class*='level'], .active[class*='lesson'], li.active, .current"
    );
    if (!active || inPluginUI(active)) return null;

    let n = active.nextElementSibling;
    while (n) {
      if (visible(n) && textOf(n)) return n;
      n = n.nextElementSibling;
    }
    return null;
  }

  function goNext(){
    return clickHuman(findNext()) || clickHuman(findNextByCourseList());
  }

  function tick(){
    const info = readCountdown();

    if (!info) {
      setStorage(null, "未检测到", "未检测到平台倒计时");
      return;
    }

    setStorage(info.seconds, info.text, "识别到平台倒计时：" + info.seconds + "s");

    const now = Date.now();
    if (info.seconds <= 1 && !jumping && now - lastJumpAt > 5000) {
      jumping = true;
      lastJumpAt = now;
      setStorage(info.seconds, info.text, "平台倒计时已到 1s，准备进入下一节");

      setTimeout(() => {
        const ok = goNext();
        setStorage(info.seconds, info.text, ok ? "已点击下一节" : "未找到下一节按钮，请手动点一次");
        setTimeout(() => { jumping = false; }, 3000);
      }, 1000);
    }
  }

  setInterval(tick, 500);
  tick();
})();

