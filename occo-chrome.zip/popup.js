const DEFAULTS = {
  enabled: true,
  playbackRate: 3,
  muted: false,
  autoNextLesson: true,
  fallbackWaitSeconds: 20,
  extraWaitSeconds: 1,
  lastStatus: "暂无状态",
  lastStatusAt: ""
};

const fields = [
  "enabled",
  "muted",
  "autoNextLesson",
  "playbackRate",
  "fallbackWaitSeconds",
  "extraWaitSeconds"
];

function getValue(el) {
  return el.type === "checkbox" ? el.checked : Number(el.value);
}

function load() {
  chrome.storage.sync.get(DEFAULTS, (settings) => {
    for (const id of fields) {
      const el = document.getElementById(id);
      if (!el) continue;
      if (el.type === "checkbox") el.checked = Boolean(settings[id]);
      else el.value = settings[id];
    }

    const time = settings.lastStatusAt ? `\n时间：${settings.lastStatusAt}` : "";
    document.getElementById("status").innerText = `状态：${settings.lastStatus}${time}`;
  });
}

function bind() {
  for (const id of fields) {
    const el = document.getElementById(id);
    el.addEventListener("change", () => {
      chrome.storage.sync.set({ [id]: getValue(el) }, load);
    });
  }
}

bind();
load();
setInterval(load, 1000);



/* === 弹窗倒计时显示补丁 === */
(function popupCountdownPatch(){
  function renderCountdown(){
    const box = document.getElementById("pageCountdownBox");
    if (!box || !chrome.storage || !chrome.storage.sync) return;
    chrome.storage.sync.get({
      pageCountdownSeconds: null,
      pageCountdownText: "未检测到",
      pageCountdownAt: ""
    }, (s) => {
      const sec = s.pageCountdownSeconds;
      const line = sec === null || sec === undefined ? "未检测到" : (sec + "s");
      const at = s.pageCountdownAt ? ("<br>更新时间：" + s.pageCountdownAt) : "";
      box.innerHTML = "页面倒计时：" + line + at;
    });
  }
  setInterval(renderCountdown, 1000);
  document.addEventListener("DOMContentLoaded", renderCountdown);
  renderCountdown();
})();

